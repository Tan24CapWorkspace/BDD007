package beans;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Registration {
	WebDriver driver;
	
	@FindBy(id="txtUserName")
	WebElement username;
	@FindBy(id="txtPassword")
	WebElement password;
	@FindBy(id="txtConfPassword")
	WebElement cpassword;
	@FindBy(id="txtFirstName")
	WebElement firstname;	
	@FindBy(id="txtLastName")
	WebElement lastname;
	@FindBy(id="rbMale")
	WebElement male;
	@FindBy(id="rbFemale")
	WebElement female;
	@FindBy(id="DOB")
	WebElement dob;
	@FindBy(id="txtEmail")
	WebElement email;
	@FindBy(id="txtAddress")
	WebElement address;
	@FindBy(name="City")
	WebElement city;
	@FindBy(id="txtPhone")
	WebElement phone;
	@FindBy(name="chkHobbies")
	WebElement hobbies;
	@FindBy(name="submit")
	WebElement submit;
	@FindBy(name="reset")
	WebElement reset;
	
	
	public Registration(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}


	public WebDriver getDriver() {
		return driver;
	}


	public WebElement getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username.sendKeys(username);
	}


	public WebElement getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password.sendKeys(password);
	}


	public WebElement getCpassword() {
		return cpassword;
	}


	public void setCpassword(String cpassword) {
		this.cpassword.sendKeys(cpassword);
	}


	public WebElement getFirstname() {
		return firstname;
	}


	public void setFirstname(String firstname) {
		this.firstname.sendKeys(firstname);
	}


	public WebElement getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname.sendKeys(lastname);
	}



	public WebElement getMale() {
		return male;
	}


	public void setMale() {
		this.male.click();
	}


	public WebElement getFemale() {
		return female;
	}


	public void setFemale() {
		this.female.click();
	}


	public WebElement getDob() {
		return dob;
	}


	public void setDob(String dob) {
		this.dob.sendKeys(dob);
	}


	public WebElement getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email.sendKeys(email);
	}


	public WebElement getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address.sendKeys(address);
	}


	public WebElement getCity() {
		return city;
	}


	public void setCity(String city) {
		Select dropdown = new Select(this.city);
		dropdown.selectByValue(city);
	}


	public WebElement getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone.sendKeys(phone);
	}


	public WebElement getHobbies() {
		return hobbies;
	}


	public void setHobbies(String hobbies) {
		if(hobbies.equals("Music")) {
			driver.findElements(By.name("chkHobbies")).get(0).click();
		}else if(hobbies.equals("Reading")) {
			driver.findElements(By.name("chkHobbies")).get(1).click();
		}else if(hobbies.equals("Movies")) {
			driver.findElements(By.name("chkHobbies")).get(2).click();
		}
	}


	public WebElement getSubmit() {
		return submit;
	}


	public void Submit() {
		this.submit.click();
	}


	public WebElement getReset() {
		return reset;
	}


	public void setReset() {
		this.reset.click();
	}
	
	
	
	
}
