package stepDefinition;

import static org.testng.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import beans.Registration;


import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestCases {
	
	
	WebDriver driver;
	Registration bean;
	
	@Before
	public void setup() {
		driver = new FirefoxDriver();
	}
	
	
	@Given("^User is on User Registration Page$")
	public void user_is_on_User_Registration_Page() throws Throwable {
		driver.get("D:\\workspace\\BDDPractice1\\HTML Files\\WorkingWithForms.html");
		bean = new Registration(driver);
	}

	@When("^User enters invalid User Name$")
	public void user_enters_invalid_User_Name() throws Throwable {
	    bean.setUsername("");
	}

	@When("^User hit submit button$")
	public void user_hit_submit_button() throws Throwable {
		System.out.println("It is called");
		bean.Submit();
	}

	@Then("^The User Name  field is invalid \"([^\"]*)\"$")
	public void the_User_Name_field_is_invalid(String arg1) throws Throwable {
		String expected = arg1;
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
	}

	@When("^User enters valid User Name but invalid password$")
	public void user_enters_valid_User_Name_but_invalid_password() throws Throwable {
		bean.setUsername("Tanmay Pathak");
		bean.setPassword("");
	}

	@Then("^The Password field is invalid \"([^\"]*)\"$")
	public void the_Password_field_is_invalid(String arg1) throws Throwable {
		String expected = arg1;
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
	}

	@When("^User enters valid User Name and Password but enters invalid data in Confirm Password field$")
	public void user_enters_valid_User_Name_and_Password_but_enters_invalid_data_in_Confirm_Password_field() throws Throwable {
		bean.setUsername("Tanmay Pathak");
		bean.setPassword("123");
		bean.setCpassword("");
	}

	@Then("^The Confirm Password  field is invalid \"([^\"]*)\"$")
	public void the_Confirm_Password_field_is_invalid(String arg1) throws Throwable {
		String expected = arg1;
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
	}

	@When("^User enters valid data in User Name,Password and Confirm Password field but invalid data in First Name field$")
	public void user_enters_valid_data_in_User_Name_Password_and_Confirm_Password_field_but_invalid_data_in_First_Name_field() throws Throwable {
		bean.setUsername("Tanmay Pathak");
		bean.setPassword("123");
		bean.setCpassword("123");
		bean.setFirstname("");
	}

	@Then("^The First Name field is invalid \"([^\"]*)\"$")
	public void the_First_Name_field_is_invalid(String arg1) throws Throwable {
		String expected = arg1;
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
	}

	@When("^User enters valid data in User Name,Password and Confirm Password field but invalid data in Last Name field$")
	public void user_enters_valid_data_in_User_Name_Password_and_Confirm_Password_field_but_invalid_data_in_Last_Name_field() throws Throwable {
		bean.setUsername("Tanmay Pathak");
		bean.setPassword("123");
		bean.setCpassword("123");
		bean.setFirstname("Tanmay");
		bean.setLastname("");
	}

	@Then("^The Last Name  field is invalid \"([^\"]*)\"$")
	public void the_Last_Name_field_is_invalid(String arg1) throws Throwable {
		String expected = arg1;
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
	}

	


	@When("^User enters valid data in User Name,Password,Confirm Password,Last Name and Date of birth field but invalid data in Email Id field$")
	public void user_enters_valid_data_in_User_Name_Password_Confirm_Password_Last_Name_and_Date_of_birth_field_but_invalid_data_in_Email_Id_field() throws Throwable {
		bean.setUsername("Tanmay Pathak");
		bean.setPassword("123");
		bean.setCpassword("123");
		bean.setFirstname("Tanmay");
		bean.setLastname("Pathak");
		bean.setEmail("");
	}

	@Then("^The Email Id \"([^\"]*)\"$")
	public void the_Email_Id(String arg1) throws Throwable {
		String expected = arg1;
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
	}
	
	@When("^User enters valid data in User Name,Password,Confirm Password and Last Name field but invalid data in Date of Birth field$")
	public void user_enters_valid_data_in_User_Name_Password_Confirm_Password_and_Last_Name_field_but_invalid_data_in_Date_of_Birth_field() throws Throwable {
		bean.setUsername("Tanmay Pathak");
		bean.setPassword("123");
		bean.setCpassword("123");
		bean.setFirstname("Tanmay");
		bean.setLastname("Pathak");
		bean.setEmail("tan@gmail.com");
		bean.setAddress("Gwalior");
		bean.setPhone("9635874521");
		bean.setDob("06-08-2020");   
	}

	@Then("^The Date Of Birth field is invalid$")
	public void the_Date_Of_Birth_field_is_invalid() throws Throwable {
		Assert.assertEquals("06-08-2020", driver.switchTo().alert().getText());
	}

	@When("^User enters valid data in User Name,Password,Confirm Password,Last Name,Date of birth and Email Id field but invalid data in Address field$")
	public void user_enters_valid_data_in_User_Name_Password_Confirm_Password_Last_Name_Date_of_birth_and_Email_Id_field_but_invalid_data_in_Address_field() throws Throwable {
		bean.setUsername("Tanmay Pathak");
		bean.setPassword("123");
		bean.setCpassword("123");
		bean.setFirstname("Tanmay");
		bean.setLastname("Pathak");
		bean.setEmail("tan@gmail.com");
		bean.setAddress("");
	}

	@Then("^The Address  field is invalid \"([^\"]*)\"$")
	public void the_Address_field_is_invalid(String arg1) throws Throwable {
		String expected = arg1;
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
	}

	

	@When("^User enters valid data in User Name,Password,Confirm Password,Last Name,Date of birth,Email Id and Address field but invalid data in Phone field$")
	public void user_enters_valid_data_in_User_Name_Password_Confirm_Password_Last_Name_Date_of_birth_Email_Id_and_Address_field_but_invalid_data_in_Phone_field() throws Throwable {
		bean.setUsername("Tanmay Pathak");
		bean.setPassword("123");
		bean.setCpassword("123");
		bean.setFirstname("Tanmay");
		bean.setLastname("Pathak");
		bean.setEmail("tan@gmail.com");
		bean.setAddress("Gwalior");
		bean.setPhone("");
	}

	@Then("^The Phone field is invalid \"([^\"]*)\"$")
	public void the_Phone_field_is_invalid(String arg1) throws Throwable {
		String expected = arg1;
		String actual = driver.switchTo().alert().getText();
		System.out.println(expected +"  "+actual+"  "+actual.equals(expected));
		Assert.assertEquals(expected, actual);
	}

	

	@When("^User clicks on Submit button with valid inputs$")
	public void user_clicks_on_Submit_button_with_valid_inputs() throws Throwable {
		bean.setUsername("Tanmay Pathak");
		bean.setPassword("123");
		bean.setCpassword("123");
		bean.setFirstname("Tanmay");
		bean.setLastname("Pathak");
		bean.setEmail("tan@gmail.com");
		bean.setPhone("9632587415");
	}

	@Then("^Redirected to Success Page$")
	public void redirected_to_Success_Page() throws Throwable {
	    driver.get("D:\\workspace\\BDDPractice1\\HTML Files\\success.html");
	}

	@When("^User clicks on Reset button$")
	public void user_clicks_on_Reset_button() throws Throwable {
	    bean.setReset();
	}

	@Then("^All fields in forms should be set to blank$")
	public void all_fields_in_forms_should_be_set_to_blank() throws Throwable {
		
	}
	
	@When("^User selects \"([^\"]*)\" radio button$")
	public void user_selects_radio_button(String arg1) throws Throwable {
	    if(arg1.equals("Male")) {
	    	bean.setMale();
	    }else if(arg1.equals("Female")) {
	    	bean.setFemale();
	    }
	}

	@Then("^\"([^\"]*)\" should be send as Gender value$")
	public void should_be_send_as_Gender_value(String arg1) throws Throwable {
		if(arg1.equals("Male")) {
	    	Assert.assertEquals(bean.getMale().isSelected(), true);
	    }else if(arg1.equals("Female")) {
	    	Assert.assertEquals(bean.getFemale().isSelected(), true);
	    }
	}

	@When("^User selects \"([^\"]*)\" city$")
	public void user_selects_city(String arg1) throws Throwable {
	    bean.setCity(arg1);
	}

	@Then("^\"([^\"]*)\" should be send city$")
	public void should_be_send_city(String arg1) throws Throwable {
		Select dropdown = new Select(driver.findElement(By.name("City")));
		if(arg1.equals("Mumbai")) {
		   Assert.assertEquals(arg1, dropdown.getFirstSelectedOption().getText());
	   }else if(arg1.equals("Pune")) {
		   Assert.assertEquals(arg1, dropdown.getFirstSelectedOption().getText());
	   }else if(arg1.equals("Bangalore")) {
		   Assert.assertEquals(arg1, dropdown.getFirstSelectedOption().getText());
	   }else if(arg1.equals("Chennai")) {
		   Assert.assertEquals(arg1, dropdown.getFirstSelectedOption().getText());
	   }
	}

	@When("^User selects \"([^\"]*)\" hobbies$")
	public void user_selects_hobbies(String arg1) throws Throwable {
	   bean.setHobbies(arg1);
	}

	@Then("^\"([^\"]*)\" should be send hobbies$")
	public void should_be_send_hobbies(String arg1) throws Throwable {
		String result = "";
		if(driver.findElements(By.name("chkHobbies")).get(0).isSelected()) {
			result = "Music";
		}else if(driver.findElements(By.name("chkHobbies")).get(1).isSelected()) {
			result = "Reading";
		}else if(driver.findElements(By.name("chkHobbies")).get(2).isSelected()) {
			result = "Movies";
		}
		
		Assert.assertEquals(arg1, result);
	}
	
	
	
	
}
