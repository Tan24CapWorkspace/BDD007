package hotelLogin;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

// pageBean.HotelLoginPageFactory;
import pageBean.HotelLoginPageFactory;

public class LoginStepDefination {

	private WebDriver driver;
	private HotelLoginPageFactory loginPageFactory;
	
	@Before
	public void setUp() {
		driver = new FirefoxDriver();
	}
	/*
	 * driver.get("D:\\workspace\\BDDCaseStudyFinal\\login.html");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		loginPageFactory = new HotelLoginPageFactory(driver);
	 * */
	
	@Given("^User is on 'login' Page$")
	public void user_is_on_login_Page() throws Throwable {
		driver.get("D:\\workspace\\BDDCaseStudyFinal_modified\\login.html");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		loginPageFactory = new HotelLoginPageFactory(driver);
	}

	@When("^user enters invalid UserName$")
	public void user_enters_invalid_UserName() throws Throwable {
	    loginPageFactory.setUserName("");
	    loginPageFactory.setLoginButton();
	}

	@Then("^display 'Please Enter UserName'$")
	public void display_Please_Enter_UserName() throws Throwable {
	    Assert.assertEquals("* Please enter userName.", loginPageFactory.getUsernameError().getText());
	}

	@When("^user enters invalid password$")
	public void user_enters_invalid_password() throws Throwable {
		loginPageFactory.setUserName("tanmay");
		loginPageFactory.setPassword("");
		loginPageFactory.setLoginButton();
	}

	@Then("^display 'Please Enter Password'$")
	public void display_Please_Enter_Password() throws Throwable {
		Assert.assertEquals("* Please enter password.", loginPageFactory.getPasswordError().getText());
	}

	@When("^User enter username as \"([^\"]*)\" and password as \"([^\"]*)\"$")
	public void user_enter_username_as_and_password_as(String arg1, String arg2) throws Throwable {
		loginPageFactory.setUserName(arg1);
	    loginPageFactory.setPassword(arg2);
	    loginPageFactory.setLoginButton();
	}

	@Then("^display 'Invalid Login Please try again'$")
	public void display_Invalid_Login_Please_try_again() throws Throwable {
		String expected = "Invalid login! Please try again!";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@Then("^display 'HotelBooking' Page$")
	public void display_HotelBooking_Page() throws Throwable {
		driver.navigate().to("D:\\workspace\\BDDCaseStudyFinal_modified\\hotelbooking.html");
		//System.out.println(driver.switchTo().alert().getText());
	}

}